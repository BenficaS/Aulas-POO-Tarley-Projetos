package br.newtonpaiva;
public class Main {
    public static void main(String[]args){
        System.out.println(" hello world - alo mundo");
    }
}