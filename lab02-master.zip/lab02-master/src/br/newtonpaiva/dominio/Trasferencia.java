package br.newtonpaiva.dominio;

public interface Trasferencia {
    void transferir(Conta destino, Double valor);
}
