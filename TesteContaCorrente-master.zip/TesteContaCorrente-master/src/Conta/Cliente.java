package Conta;

public class Cliente {

    public String nome;

}
